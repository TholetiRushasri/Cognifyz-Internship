document.querySelectorAll('.thumbnail').forEach(thumbnail => {
    thumbnail.addEventListener('click', (e) => {
      const overlay = document.createElement('div');
      overlay.classList.add('overlay');
      
      const enlargedImage = document.createElement('div');
      enlargedImage.classList.add('enlarged');
      
      const clickedImage = document.createElement('img');
      clickedImage.src = e.target.src;
      clickedImage.alt = e.target.alt;
      
      enlargedImage.appendChild(clickedImage);
      document.body.appendChild(overlay);
      document.body.appendChild(enlargedImage);
      
      overlay.addEventListener('click', () => {
        document.body.removeChild(enlargedImage);
        document.body.removeChild(overlay);
      });
      
      enlargedImage.addEventListener('click', () => {
        document.body.removeChild(enlargedImage);
        document.body.removeChild(overlay);
      });
    });
  });
  